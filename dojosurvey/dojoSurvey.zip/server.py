from flask import Flask, render_template, request, redirect
app = Flask(__name__)
@app.route('/') #root route
def index(): #run this function
    return render_template("index.html") #render index.html

@app.route('/resulting', methods=['POST']) #send results to /result
def result(): #run this function
    name = request.form['name'] #request all of this data
    location = request.form['location']
    favlang = request.form['favlang']
    comment = request.form['comment']
    print request.form #print to console
    return render_template("/result.html", name=name, location=location, favlang=favlang, comment=comment) #send the data in these variables to result.html and render that page
app.run(debug=True)
